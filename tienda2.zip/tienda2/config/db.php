<?php

$conexion = mysqli_connect('localhost','root','','tienda2');

// if($conexion){
//     echo "Conexión exitosa!";
// }else{
//     echo "No hay conexión";
// }
?>